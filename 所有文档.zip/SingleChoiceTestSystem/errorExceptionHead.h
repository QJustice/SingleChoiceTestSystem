﻿#pragma once
#ifndef _ERROREXCEPTION_
#define _ERROREXCEPTION_

//异常处理

void exitErrorTheSystem();		//程序异常退出
void unknownIdentity();		//身份验证异常
void refreshBuffer();		//刷新缓冲区 


#endif